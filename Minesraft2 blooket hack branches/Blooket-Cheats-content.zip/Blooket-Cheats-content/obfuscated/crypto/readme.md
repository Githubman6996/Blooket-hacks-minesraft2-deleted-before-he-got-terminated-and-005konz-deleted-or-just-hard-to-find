# Crypto Hack Cheats
[^1]: [CoderQCFromScraatch](https://github.com/CoderQCFromScraatch)

## [Always Quintuple Crypto](alwaysQuintupleCrypto.js)[^1]
Every choice will be replaced with a custom made Quintuple Crypto option. Use this only after gaining some crypto!