# ⚠️ IMPORTANT ⚠️
If any cheats are not working, try copying them from the repo again, _then_ make an issue
## [Support Server](https://discord.gg/QerPBatcca)
## [Instructions for importing bookmarklets](tutorial/readme.md)

Cheats that change the game
## List of Cheats

### [Crypto Hack](obfuscated/crypto/)
 * [Always Quintuple](obfuscated/crypto/alwaysQuintupleCrypto.js)<br>
### [Racing](unobfuscated/racing/)
 * [Delay Win](unobfuscated/racing/delayWin.js)<br>
