# 1. Navigate to `obfuscated` folder
![Opera GX part 1](/tutorial/chrome/part%20(1).png)
# 2. Open `Bookmarklets.html` file
![Opera GX part 2](/tutorial/chrome/part%20(2).png)
# 3. Click `Download` or `View raw`
![Opera GX part 3](/tutorial/chrome/part%20(3).png)
# 4. Ctrl + S or Right click > Save as
![Opera GX part 4](/tutorial/chrome/part%20(4).png)
# 5. Save file
![Opera GX part 5](/tutorial/chrome/part%20(5).png)
# 6. Click on the three dots in the top right > Bookmarks > Import bookmarks and settings
![Opera GX part 6](/tutorial/chrome/part%20(6).png)
# 7. Switch to `Bookmarks HTML File`
![Opera GX part 7](/tutorial/chrome/part%20(7).png)
# 8. Click on `Choose File`
![Opera GX part 8](/tutorial/chrome/part%20(8).png)
# 9. Choose the saved file from step 5
![Opera GX part 9](/tutorial/chrome/part%20(9).png)
# 10. Happy cheating
![Opera GX part 10](/tutorial/chrome/part%20(10).png)