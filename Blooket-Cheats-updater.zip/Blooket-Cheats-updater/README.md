This branch is for the GitHub Pages site for the most updated blooket cheats.
https://Minesraft2.github.io/Blooket-Cheats