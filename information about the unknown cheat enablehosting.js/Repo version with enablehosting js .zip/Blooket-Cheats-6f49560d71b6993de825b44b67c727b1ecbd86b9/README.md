# ⚠️ ALL CHEATS ARE SUBJECT TO CHANGE
[Support Server](https://discord.gg/QerPBatcca)

Cheats made by someone who knows more about what they're doing

### Bookmarklets
When ever you need to add the cheats to your bookmarks, download [this file](obfuscated/Bookmarklets.html) and import it to your bookmarks (chrome://bookmarks)

# Todo

- [x] Finish Global cheats
- [ ] More Racing cheats
- [X] New Gamemode cheats when new UI comes out
- [x] New UI cheats

[^1]: [Overtime](https://github.com/overtimepog)
## List of Cheats
### [Global](obfuscated/global/)
[Anti Suspend](obfuscated/global/antiSuspend.js)<br>
[Auto Answer](obfuscated/global/autoAnswer.js)<br>
[Auto Sell](obfuscated/global/autoSell.js)<br>
[Auto Buy](obfuscated/global/autoBuy.js)<br>
[Highlight Answers](obfuscated/global/highlightAnswers.js)<br>
[Spoof Blooks](obfuscated/global/spoofBlooks.js)<br>
[Get Rewards](obfuscated/global/getRewards.js)<br>
[Every Answer Correct](obfuscated/global/everyAnswerCorrect.js)<br>
[Unlock Plus Gamemodes](obfuscated/global/unlockPlusGamemodes.js)<br>

**[Intervals](obfuscated/global/intervals/)**<br>
[Auto Answer](obfuscated/global/intervals/autoAnswer.js)<br>
[Highlight Answers](obfuscated/global/intervals/highlightAnswers.js)<br>
### [Brawl](obfuscated/brawl/)
[Invincibility](obfuscated/brawl/invincibility.js)<br>
[Next Level](obfuscated/brawl/nextLevel.js)<br>
[Remove Enemies](obfuscated/brawl/removeEnemies.js)[^1]<br>
[Remove Obstacles](obfuscated/brawl/removeObstacles.js)[^1]<br>
[Reset Health](obfuscated/brawl/resetHealth.js)<br>
### [Cafe](obfuscated/cafe/)
[Max Items](obfuscated/cafe/maxItems.js)<br>
[Remove Customers](obfuscated/cafe/removeCustomers.js)<br>
[Reset Abilities](obfuscated/cafe/resetAbilities.js)<br>
[Set Cash](obfuscated/cafe/setCash.js)<br>
[Stock Food](obfuscated/cafe/stockFood.js)<br>
### [Crypto Hack](obfuscated/crypto/)
[Choice ESP](obfuscated/crypto/choiceESP.js)<br>
[Password ESP](obfuscated/crypto/passwordESP.js)<br>
[Remove Hack](obfuscated/crypto/removeHack.js)<br>
[Set Crypto](obfuscated/crypto/setCrypto.js)<br>
[Set Password](obfuscated/crypto/setPassword.js)<br>
[Steal Player's Crypto](obfuscated/crypto/stealPlayersCrypto.js)<br>
### [Deceptive Dinos](obfuscated/dinos/)
[Rock ESP](obfuscated/dinos/rockESP.js)<br>
[Set Fossils](obfuscated/dinos/setFossils.js)<br>
[Set Multiplier](obfuscated/dinos/setMultiplier.js)<br>
[Stop Cheating](obfuscated/dinos/stopCheating.js)<br>
### [Tower of Doom](obfuscated/doom/)
[Fill Deck](obfuscated/doom/fillDeck.js)<br>
[Max Cards](obfuscated/doom/maxCards.js)<br>
[Max Health](obfuscated/doom/maxHealth.js)<br>
[Max Stats](obfuscated/doom/maxStats.js)<br>
[Min Enemy](obfuscated/doom/minEnemy.js)<br>
[Set Coins](obfuscated/doom/setCoins.js)<br>
### [Factory](obfuscated/factory/)
[Max Blooks](obfuscated/factory/maxBlooks.js)<br>
[Remove Glitches](obfuscated/factory/removeGlitches.js)<br>
[Set All Mega Bot](obfuscated/factory/setAllMegaBot.js)<br>
[Set Cash](obfuscated/factory/setCash.js)<br>
### [Fishing Frenzy](obfuscated/fishing/)
[Frenzy](obfuscated/fishing/frenzy.js)<br>
[Set Lure](obfuscated/fishing/setLure.js)<br>
[Set Weight](obfuscated/fishing/setWeight.js)<br>
### [Gold Quest](obfuscated/gold/)
[Chest ESP](obfuscated/gold/chestESP.js)<br>
[Reset Player's Gold](obfuscated/gold/resetPlayersGold.js)<br>
[Set Gold](obfuscated/gold/setGold.js)<br>
[Swap Gold](obfuscated/gold/swapGold.js)<br>
### [Crazy Kingdom](obfuscated/kingdom/)
[Choice ESP](obfuscated/kingdom/choiceESP.js)<br>
[Disable Toucan](obfuscated/kingdom/disableToucan.js)<br>
[Max Stats](obfuscated/kingdom/maxStats.js)<br>
[Set Guests](obfuscated/kingdom/setGuests.js)<br>
[Skip Guest](obfuscated/kingdom/skipGuest.js)<br>
### [Racing](obfuscated/racing/)
[Instant Win](obfuscated/racing/instantWin.js)<br>
### [Blook Rush](obfuscated/rush/)
[Set Blooks](obfuscated/rush/setBlooks.js)<br>
[Set Defense](obfuscated/rush/setDefense.js)<br>
### [Tower Defense](obfuscated/tower-defense/)
[Max Towers](obfuscated/tower-defense/maxTowers.js)<br>
[Remove Ducks](obfuscated/tower-defense/removeDucks.js)<br>
[Remove Enemies](obfuscated/tower-defense/removeEnemies.js)<br>
[Place Towers Anywhere](obfuscated/tower-defense/removeObsticles.js)<br>
[Set Damage](obfuscated/tower-defense/setDmg.js)<br>
[Set Round](obfuscated/tower-defense/setRound.js)<br>
[Set Tokens](obfuscated/tower-defense/setTokens.js)<br>
