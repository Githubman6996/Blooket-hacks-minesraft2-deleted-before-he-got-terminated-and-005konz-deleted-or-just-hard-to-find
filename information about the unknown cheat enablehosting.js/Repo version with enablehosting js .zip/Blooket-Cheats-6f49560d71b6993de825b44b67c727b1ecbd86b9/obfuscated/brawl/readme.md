# Monster Brawl Cheats

## [Invincibility](invincibility.js)
Makes you invincible
## [Next Level](nextLevel.js)
Gives you another level
## [Remove Enemies](removeEnemies.js)
Removes all currennt enemies
## [Remove Obstacles](removeObstacles.js)
Removes all rocks and obstacles
## [Reset Health](resetHealth.js)
Resets health and gives invincibility for 3 seconds