# Fishing Frenzy Cheats

## [Frenzy](frenzy.js)
Sets everyone to frenzy mode

## [Set Lure](setLure.js)
Sets fishing lure (range 1 - 5)

## [Set Weight](setWeight.js)
Sets weight